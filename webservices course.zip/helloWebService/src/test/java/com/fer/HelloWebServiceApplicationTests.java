package com.fer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
