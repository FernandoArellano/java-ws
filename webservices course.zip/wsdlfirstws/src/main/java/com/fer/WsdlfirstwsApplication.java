package com.fer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WsdlfirstwsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WsdlfirstwsApplication.class, args);
	}

}
